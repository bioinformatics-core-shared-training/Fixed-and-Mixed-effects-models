
##########################################################################
#====== Section 1: importation and descriptive analysis =================

# read diet data
diet = read.csv("data/diet.csv",row.names=1)

# explore the data
head(diet)
table(diet$diet.type)

# defining a new column weight.loss
diet$weight.loss = diet$initial.weight - diet$final.weight 

# convert diet type to factor
diet$diet.type   = factor(diet$diet.type,levels=c("A","B","C"))

# convert gender to factor
diet$gender = factor(diet$gender,levels=c("Female","Male"))

# create a box-plot diet.type vs eight.loss
boxplot(weight.loss~diet.type, data=diet, col="light gray",
        ylab = "Weight loss (kg)", xlab = "Diet type")
abline(h=0,col="blue")

##########################################################################



##########################################################################
#============ Section 2: ANOVA ==========================================

# fisher - one-way ANOVA
# Samples from normal populations with equal variances
diet.fisher  = aov( weight.loss~diet.type, data=diet )
summary(diet.fisher)


# Welch’s  one-way ANOVA
# Samples from normal populations with unequal equal variances
diet.welch   = oneway.test(weight.loss~diet.type,data=diet)
print(diet.welch)

# Kruskal-Wallis one-way ANOVA
# No assumption on the distribution of the data
diet.kruskal = kruskal.test(weight.loss~diet.type,data=diet)
print(diet.kruskal)


# the difference between two means, the Fisher’s ANOVA (function aov()) and 
# the Student’s t-test (function t.test() with argument var.equal set to TRUE)
# leads to the same results.
# when df=1: t-distribution = sqrt(Fisher)
summary(aov(weight.loss~diet.type, data=diet[diet$diet.type!="B",]))

t.test(weight.loss~diet.type,data=diet[diet$diet.type!="B",], var.equal = TRUE)
##########################################################################



##########################################################################
#============== Section 3: Model check ===================================

# mean and median weight loss per group:
mean_group   = tapply(diet$weight.loss, diet$diet.type, mean)
mean_group
median_group = tapply(diet$weight.loss, diet$diet.type, median)
median_group

# calculate residuals:
diet$resid.mean   = (diet$weight.loss - mean_group[as.numeric(diet$diet.type)])
diet$resid.median = (diet$weight.loss - median_group[as.numeric(diet$diet.type)])

# display a boxplot of the residuals per group to assess if (i) the variance per 
# display a QQ-plot of the residuals of the mean model to assess if normality of 
# the residuals seems crediblegroups are similar (ii) normality of the residuals 
# per group seems credible

par(mfrow=c(1,2), mar=c(4.5,4.5,2,0)) 

# box-plot
boxplot(resid.mean~diet.type,data=diet,
        main="Residual boxplot per group",
        col="light gray",
        xlab="Diet type",
        ylab="Residuals")

abline(h=0,col="blue")

# QQ-plot
col_group = rainbow(nlevels(diet$diet.type))
qqnorm(diet$resid.mean,
       col=col_group[as.numeric(diet$diet.type)])
qqline(diet$resid.mean)
legend("top",legend=levels(diet$diet.type),
       col=col_group,
       pch=21,
       ncol=3,
       box.lwd=NA)


# perform a Shapiro’s test to assess is there is enough evidence 
# that the residuals are not normally distributed
shapiro.test(diet$resid.mean)

# perform a Bartlett’s test to assess is there is enough evidence 
# that the residuals per group do not have different variance
bartlett.test(diet$resid.mean~as.numeric(diet$diet.type))

##########################################################################




##########################################################################
#============== Section 4: Two-way ANOVA =============================

# diet.type+gender: no interaction
# diet.type*gender: interaction
diet.fisher = aov(weight.loss ~ diet.type*gender, data=diet)
summary(diet.fisher)

# compare the output of the function aov() to the one of the function lm()

anova(lm(weight.loss~diet.type*gender, data=diet))
##########################################################################


##########################################################################
#============== Section 5: Practicals =============================
# Analyse the two following datasets with the suitable analysis:

#------------------------------------------------------------------------#
# (i) amess.csv
amess = read.csv("data/amess.csv")

# explore the data
table(amess$treatmnt)
# treatment 1: 50% N2O and 50% O2 continuously for 24 hours
# treatment 2: 50% N2O and 50% O2 during the operation
# treatment 2:No N2O but 35-50% O2 continuously for 24 hours

# convert treatment into factots
amess$treatmnt = factor(amess$treatmnt,levels=c(1,2,3),
                        labels=c("1","2","3"))
# box-plots
boxplot(folate~treatmnt, data=amess,
        col="light gray",
        ylab = "Folate levels", 
        xlab = "Treatmnt")

# mean Folate levels  per group:
mean_group   = tapply(amess$folate, amess$treatmnt, mean)
mean_group
amess$resid.mean   = (amess$folate - mean_group[as.numeric(amess$treatmnt)])


# residual box-plot and qq-plot
par(mfrow=c(1,2),mar=c(4.5,4.5,2,0)) 
#
boxplot(resid.mean~treatmnt, data=amess,
        main="Residual boxplot per group",
        col="light gray",
        xlab="treatmnt",
        ylab="Residuals")
abline(h=0,col="blue")
#
col_group = rainbow(nlevels(amess$treatmnt))
qqnorm(amess$resid.mean, col=col_group[as.numeric(amess$treatmnt)])
qqline(amess$resid.mean)
legend("top",legend=levels(diet$diet.type),col=col_group,pch=21,ncol=3,box.lwd=NA)

# perform a Shapiro’s test to assess  the normality
# Null hypothesis: the data is normally distributed
shapiro.test(amess$resid.mean)

# Bartlett’s test to assess the equality of variances
# Null hypothesis: the data have equal variances
bartlett.test(amess$resid.mean~as.numeric(amess$treatmnt))


amess.fisher = aov(folate ~ treatmnt, data=amess)
summary(amess.fisher)
amess.fisher
#------------------------------------------------------------------------#

# (ii) globalBreastCancerRisk.csv
# whether the number of breast cancer cases is significantly different in 
# different regions of the world.
bc = read.csv("data/globalBreastCancerRisk.csv")
dim(bc)

# explore the data: continent vs NewCasesOfBreastCancerIn2002
table(bc$continent)


# box-plots
boxplot(NewCasesOfBreastCancerIn2002~continent, 
        data=bc,
        col="light gray",
        ylab = "NewCasesOfBreastCancerIn2002", 
        xlab = "Continent")

table(bc$continent)

# remove the Oceania group as it has only two observations
bc = bc[bc$continent!="Oceania",]
table(bc$continent)


# convert continent into factors
bc$continent = factor(bc$continent,
                      levels=c("Africa",
                               "Asia",
                               "Europe",
                               "Americas"
                               ))


# mean NewCasesOfBreastCancerIn2002 per group:
mean_group   = tapply(bc$NewCasesOfBreastCancerIn2002, bc$continent, mean)
mean_group
bc$resid.mean   = (bc$NewCasesOfBreastCancerIn2002 - mean_group[as.numeric(bc$continent)])



# residual box-plot and qq-plot
par(mfrow=c(1,2),mar=c(4.5,4.5,2,0)) 
#
boxplot(resid.mean~continent, 
        data=bc,
        main="Residual boxplot per group",
        col="light gray",
        xlab="Continent",
        ylab="Residuals")
abline(h=0,col="blue")
#
col_group = rainbow(nlevels(bc$continent))
qqnorm(bc$resid.mean, col=col_group[as.numeric(bc$continent)])
qqline(bc$resid.mean)
legend("top",legend=levels(diet$diet.type),col=col_group,pch=21,ncol=3,box.lwd=NA)



# perform a Shapiro’s test to assess  the normality
shapiro.test(bc$resid.mean)
# Bartlett’s test to assess the equality of variances
bartlett.test(bc$resid.mean~as.numeric(bc$continent))

# both normality and equality of variances violated
# Therefore Kruskal-Wallis test is alternative
kruskal.test(NewCasesOfBreastCancerIn2002~continent, data=bc)

##########################################################################
