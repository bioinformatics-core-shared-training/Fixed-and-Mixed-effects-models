##########################################################################
#====== Section 1: Simple Regression ====================================
# simple linear regression using trees data (internal data)
# load the data
data(trees)
 
# scatter plot
plot(Volume~Girth, data=trees)
# fit the model
m1 = lm( Volume~Girth, data=trees)
# add fit line to the plot
abline(m1)

# Intercept = -36.9435, pval = 7.62e-12
# NH: Intercept = 0
# AH: Intercept is significantly different from zero
# Girth (slope) = 5.0659, pval = 2e-16
# NH: Girth = 0
# AH: Girth is significantly different from zero
summary(m1)


# correlation between Volume and Girth
# Two degrees of freedom are lost in estimating the slope and intercept of the line
cor.test(trees$Volume,trees$Girth)

# Model residuals can be readily accessed using the resid() function:
hist(resid(m1), breaks=10, col="light grey")
# Diagnostic plots for the model can reveal whether or not modelling assumptions are reasonable
fitted = fitted(m1)
resid = resid(m1)
plot(fitted, resid, xlab="Fitted values", ylab="Raw residuals")
##########################################################################



##########################################################################
#====== Section 2: Assessing the quality of linear models ================
# Let’s see what happens if we try to describe a non-linear relationship using a linear model
# generate numbers
z = seq(0,1.5*pi,0.2)
# plot the data
plot(sin(z)~z)
m2 = lm(sin(z) ~ z)
abline(m2)

summary(m2)


# By observing strong patterns in the diagnostic plots, we can see that the modelling assumptions
# are not satisified in this case.
fitted = fitted(m2)
resid = resid(m2)
plot(fitted, resid, xlab="Fitted values", ylab="Raw residuals")

##########################################################################



##########################################################################
#====== Section 3: Modelling Non-Linear Relationships ===================

# use in-built data cars
data(cars)

plot(dist~speed, data=cars)
m3 = lm(dist~speed,data=cars)
abline(m3)

summary(m3)


# model check
fitted = fitted(m3)
resid = resid(m3)
plot(fitted, resid, xlab="Fitted values", ylab="Raw residuals")

# In this case, variance stability can be aided by a square-root transformation 
# of the response variable:
plot(sqrt(dist)~speed,data=cars)
m4 = lm(sqrt(dist)~speed,data=cars)
abline(m4)

# model check
fitted = fitted(m4)
resid = resid(m4)
plot(fitted, resid, xlab="Fitted values", ylab="Raw residuals")

summary(m4)


# We’ll now try a log-log transformation, that is applying a log transformation 
# to the predictor and response variables. This represents a power 
# relationship between the two variables.

plot(log(dist)~log(speed),data=cars)
m5 = lm(log(dist)~log(speed),data=cars)
abline(m5)

# model check
fitted = fitted(m5)
resid = resid(m5)
plot(fitted, resid, xlab="Fitted values", ylab="Raw residuals")
summary(m5)


# The diagnostic plots don’t look too unreasonable. However, again the intercept 
# term does not have significant utility. So we’ll now remove it from the model:

m6 = lm(log(dist) ~ 0+log(speed), data=cars)
fitted = fitted(m6)
resid = resid(m6)
plot(fitted, resid, xlab="Fitted values", ylab="Raw residuals")

summary(m6)

# This model seems reasonable. We can now transform the model back, and display 
# the regression curve on the plot:
plot(dist~speed, data=cars)
x = order(cars$speed)
lines(exp(fitted(m6))[x]~cars$speed[x])

##########################################################################





##########################################################################
#====== Section 4: Practical Exercises ==================================

#------------------------------------------------------------------------#
# Exercise 1: Old Faithful data set
# load data
data(faithful)

# waiting as as  the independent variable
# eruptions as the dependent variable
# Explore data
head(faithful)



# fit the model
m7 = lm(eruptions~waiting,data=faithful)
summary(m7)

# What are the values of the estimates of the intercept and coefficient of 'waiting'?
# intercept: -1.874016
# coefficient of 'waiting': 0.075627

# What is the R^2 value?
# R^2: 0.8115

# Does the model have significant utility?
# Yes, the model has significant utility as the p-value is less than 0.05

# Are neither, one, or both of the parameters significantly different from zero?
# Both parameters are significantly different from zero as the p-values are less than 0.05

# Can you conclude that there is a linear relationship between the two variables?
# Yes, there is a linear relationship between 
# the two variables as the p-value is less than 0.05, but 
# In the absence of other information, this summary would indicate a linear relationship 
# between the two variables. However, we cannot conclude that without first checking that 
# the modelling assumptions have been satisfied...

# scatter plot
plot(eruptions~waiting, data=faithful)

# The observations appear to cluster in two groups.

# Draw the regression line corresponding to your model onto the plot. Based on 
# this graphical representation, does the model seem reasonable?
plot(eruptions~waiting,data=faithful)
abline(m7)
# At a glance, the model seems to describe the overall dependence of eruptions on 
# waiting time reasonably well. However, this is misleading...

# Generate the diagnostic plot of residuals versus fitted values corresponding 
# to your model. Contemplate the appropriateness of the model for describing the 
# relationship between eruption duration and waiting time.
fitted = fitted(m7)
resid = resid(m7)
plot(fitted, resid, xlab="Fitted values", ylab="Raw residuals")

# There is strong systematic behavior in the plot of residuals versus fitted values. 
# This indicates that the relationship/dependence is different or more complicated than can 
# be described with the simple linear model.
# Specifically, it should be identified what causes observations to fall into one or other of the 
# two groups. Differences between the two groups should be accounted for when modelling the relationship. 
# It seems that the direct dependence of `eruptions` on `waiting` is not as strong as is indicated by 
# the simple linear model.




#------------------------------------------------------------------------#
# Exercise 1: Anscombe datasets

# load data
data(anscombe)

# explore data
head(anscombe)

# For each of the four datasets, calculate and test the correlation between 
# the x and y variables. What do you conclude?

# between x1 and y1
cor(x=anscombe$x1, y=anscombe$y1)
# cor test
cor.test(anscombe$x1, anscombe$y1)


# between x2 and y2
cor(x=anscombe$x2, y=anscombe$y2)
# cor test
cor.test(anscombe$x2, anscombe$y2)

# between x3 and y3
cor(x=anscombe$x3, y=anscombe$y3)
# cor test
cor.test(anscombe$x3, anscombe$y3)

# between x4 and y4
cor(x=anscombe$x4, y=anscombe$y4)
# cor test
cor.test(anscombe$x4, anscombe$y4)
# All four datasets seem to exhibit positive linear relationships, with the same 
# correlation and the same p-value.


# For each of the four datasets, create a linear model that regresses y on x. 
# Look at the summaries corresponding to these models. What do you conclude?

# lm between x1 and y1
summary(lm(y1~x1, data=anscombe))

# lm between x2 and y2
summary(lm(y2~x2, data=anscombe))

# lm between x3 and y3
summary(lm(y3~x3, data=anscombe))

# lm between x4 and y4
summary(lm(y4~x4, data=anscombe))
# The summaries are essentially identical for all four linear models.


# For each of the four datasets, create a plot of y against x. What do you conclude?
# plot between x1 and y1
plot(y1~x1, data=anscombe)

# plot between x2 and y2
plot(y2~x2, data=anscombe)

# plot between x3 and y3
plot(y3~x3, data=anscombe)

# plot between x4 and y4
plot(y4~x4, data=anscombe)

# The four datasets are very different, with very different relationships between the x and y variables.
# This demonstrates how very different datasets can appear to be very similar when looking solely at summary statistics.
# We conclude that it is always important to perform exploratory data analysis, and look at the data before modelling.


#------------------------------------------------------------------------#
# Exercise 3: Pharmacokinetics of Indomethacin

# load data
data(Indometh)

# time as the dependent variable
# conc as the independent variable
# explore data
head(Indometh)


# Plot Indometh$time versus Indometh$conc (concentration). What is the nature of 
# the relationship between time and conc?
plot(time~conc,data=Indometh)
# There is a non-linear negative relationship between time and concentration.

# Apply monotonic transformations to the data so that a simple linear regression 
# model can be used to model the relationship (ensure both linearity and stabilised variance, 
#within reason). Create a plot of the transformed data, to confirm that the relationship seems linear.

plot(log(time)~log(conc),data=Indometh)


# creating the linear model, inspect the diagnostic plots to ensure that the assumptions 
# are not violated (too much). Are there any outliers with large influence? What are the 
# parameter estimates? Are both terms significant?
m8 = lm(log(time)~log(conc),data=Indometh)
fitted = fitted(m8)
resid = resid(m8)
plot(fitted, resid, xlab="Fitted values", ylab="Raw residuals")

# The diagnostic plots indicate that the residuals aren't perfectly Normally distributed, 
# but the modelling assumptions aren't violated so much as to inhibit construction of a model.
summary(m8)

# Intercept = -0.4203
# Coefficient of log(conc) = -0.9066
# Both terms are significantly different from zero.

# Add a line to the plot showing the linear relationship between the transformed data.
plot(log(time)~log(conc),data=Indometh)
abline(m8)


# regenerate the original plot of time versus conc (i.e. the untransformed data). 
# Using the lines function, add a curve to the plot corresponding to the fitted values of the model.
plot(time~conc,data=Indometh)
idx <- order(Indometh$conc)
lines(exp(fitted(m8))[idx]~Indometh$conc[idx])
##########################################################################



