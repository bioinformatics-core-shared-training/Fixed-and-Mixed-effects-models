##########################################################################
#====== Section 1: A simple example of random effects ====================

# load libraries
library(nlme) 
library(tidyverse)  

# lod data
TumVol = read.csv("data/TumVol.csv") # Load the TumVol dataset
TumVol   

# plot
TumVol %>% 
  mutate(IDmouse = factor(IDmouse)) %>%
  ggplot(aes(x = TVolume, y = IDmouse, colour = IDmouse)) +
  geom_point() 

# Statistical analysis
fitModel1 <- lm(TVolume ~ 1, data=TumVol)
summary(fitModel1)

# plot residuals
TumVol$resid <- resid(fitModel1)
TumVol %>% 
  mutate(IDmouse = factor(IDmouse)) %>%
  ggplot(aes(x = resid, y = IDmouse, colour = IDmouse)) +
  geom_point() +
  geom_vline(xintercept = 0, linetype = "dashed", color = "red")


# Fixed-effects models
TumVol$IDmouse <- factor(TumVol$IDmouse, ordered = FALSE, levels = c(1,2,3,4,5,6)) # IDmouse as categorical variable
fitModel2 <- lm(TVolume ~ IDmouse, data=TumVol)
summary(fitModel2)

# residuals plot
TumVol$resid <- resid(fitModel2)
TumVol %>% 
  mutate(IDmouse = factor(IDmouse)) %>%
  ggplot(aes(x = resid, y = IDmouse, colour = IDmouse)) +
  geom_point() +
  geom_vline(xintercept = 0, linetype = "dashed", color = "red")

# Bartlett’s homoscedasticity test
bartlett.test(resid ~ IDmouse, data = TumVol) 

# residual histogram
hist(TumVol$resid)

# Check normality of residuals using Q-Q plot
qqnorm(TumVol$resid)
qqline(TumVol$resid, col="red") 

# Check normality of residuals using Shapiro-Wilk normality test
shapiro.test(TumVol$resid)

# compare models
anova(fitModel1, fitModel2)




# Random-effects models
fitModel3 <- lme(TVolume ~ 1, random = ~1|IDmouse, data=TumVol)
summary(fitModel3)

rndEffects <- ranef(fitModel3)
rndEffects <- rndEffects$'(Intercept)'
rndEffects

# residual plots
TumVol$resid <- resid(fitModel3)
qqnorm(TumVol$resid)
qqline(TumVol$resid, col="red") 

# Shapiro-Wilk normality test
shapiro.test(TumVol$resid) 

# Bartlett’s homoscedasticity test
bartlett.test(resid ~ IDmouse, data = TumVol) 


# Q-Q plot 
qqnorm(rndEffects) 
qqline(rndEffects, col="red") 

# Shapiro-Wilk normality test
shapiro.test(rndEffects) 

# Bartlett’s homoscedasticity test
bartlett.test(resid ~ IDmouse, data = TumVol) 
# Random effects mean around zero
summary(rndEffects) 

##########################################################################



##########################################################################
#====== Section 2: Tumour growth curve analysis ==========================

# load data
TGCdSet = read.csv("data/TGCdSet.csv") # Load the TGCdSet dataset
head(TGCdSet)       

# Data management
TGCdSet$IDmouse <- factor(TGCdSet$IDmouse, ordered = FALSE) # Categorical variable
TGCdSet$ExpGroup <- factor(TGCdSet$ExpGroup, ordered = FALSE, 
                           levels = c("Vehicle", "Carboplatin","Gefitinib","Carboplatin + Gefitinib")) 

# Statistical analysis
# Graphical checks
dBaseSet = subset(TGCdSet, time == 0)

ggplot(dBaseSet, aes(x=ExpGroup, y=TVolume)) + 
  geom_jitter(position=position_jitter(0.1)) +
  stat_summary(aes(x=ExpGroup, y=TVolume), fun = mean, colour="red", geom="point")


# Formal tools: hypothesis testing
# Kruskal-Wallis Rank Sum test
kruskal.test(TVolume ~ ExpGroup, data = dBaseSet) 

# compare models
anovaTest = aov(TVolume ~ ExpGroup, data = dBaseSet)
summary(anovaTest)

# plots
p <- ggplot(data=TGCdSet, aes(x=time, y=TVolume, group=IDmouse)) +
  geom_line( linetype = "solid",color="black") + 
  stat_summary( fun = mean, colour="red", geom="line", group=1)

p + 
  facet_grid(. ~ ExpGroup)


# plots
TGCdSet$TVlog = log(TGCdSet$TVolume)

p <- ggplot(data=TGCdSet, aes(x=time, y=TVlog, group=IDmouse)) +
  geom_line( linetype = "solid",color="black") + 
  stat_summary( fun = mean, colour="red", geom="line", group=1)
p + 
  facet_grid(. ~ ExpGroup)


# Model development
fitModel0 <- lme(TVlog ~ time + time:ExpGroup, 
                 random= ~1|IDmouse,  
                 method="REML", data = TGCdSet)

# Checking different slope by mouse
fitModel1 <- lme(TVlog ~ time + time:ExpGroup, 
                 random= ~1+time|IDmouse,  
                 method="REML", data = TGCdSet)
anova(fitModel1,fitModel0)



# Checking different intercept by experimental group
fitModel0ml <- lme(TVlog ~ time + time:ExpGroup, 
                   random= ~1+time|IDmouse,  
                   method="ML", data = TGCdSet)
fitModel1ml <- lme(TVlog ~ ExpGroup + time + time:ExpGroup, 
                   random= ~1+time|IDmouse,  
                   method="ML", data = TGCdSet)
anova(fitModel1ml,fitModel0ml)



# Checking a quadratic term for the time variable, overall and by experimental group
TGCdSet$time2 = (TGCdSet$time)^2
fitModel0ml <- lme(TVlog ~ time + time:ExpGroup, 
                   random= ~1+time|IDmouse,  
                   method="ML", data = TGCdSet)
fitModel2ml <- lme(TVlog ~ time + time2 + time:ExpGroup, 
                   random= ~1+time|IDmouse,  
                   method="ML", data = TGCdSet)
fitModel3ml <- lme(TVlog ~ time + time2 + (time+time2):ExpGroup, 
                   random= ~1+time|IDmouse,  
                   method="ML", data = TGCdSet)
anova(fitModel2ml,fitModel0ml)



# compare models
anova(fitModel3ml,fitModel0ml)

# Checking a quadratic term for the time variable, overall and by experimental group
fitModel3 <- lme(TVlog ~ time + time2 + (time+time2):ExpGroup, 
                 random= ~1+time|IDmouse,  
                 method="REML", data = TGCdSet)
TGCdSet$resid <- resid(fitModel3) # Raw residuals
TGCdSet$fitted <- fitted(fitModel3) # Fitted values


# Residuals by fitted value
ggplot(data=TGCdSet, aes(x= fitted, y=resid), group=IDmouse) +
  geom_point() + 
  geom_hline(yintercept=0, linetype="dashed", color = "blue") +
  labs(title = "Residuals by fitted value", x = "Fitted values", y = "Residuals")

# Residuals by time
ggplot(data=TGCdSet, aes(x= time, y=resid), group=IDmouse) +
  geom_point() + 
  geom_hline(yintercept=0, linetype="dashed", color = "blue") +
  labs(title = "Residuals by time", x = "Time", y = "Residuals") +
  stat_summary(aes(y=resid, group=1), fun = mean, colour="red", geom="line", group=1)

# Residuals by time and experimental group
ggplot(data=TGCdSet, aes(x= time, y=resid), group=IDmouse) +
  geom_point() + 
  geom_hline(yintercept=0, linetype="dashed", color = "blue") +
  labs(title = "Residuals by time and experimental group", x = "Time", y = "Residuals") +
  stat_summary(aes(y=resid, group=1), fun = mean, colour="red", geom="line", group=1) + facet_grid(. ~ ExpGroup)

# Bartlett’s homoscedasticity test
bartlett.test(resid ~ ExpGroup, data = TGCdSet) 

# Residuals by mouse
ggplot(data=TGCdSet, aes(x= IDmouse, y=resid), group=IDmouse) +
  geom_point() + 
  geom_hline(yintercept=0, linetype="dashed", color = "blue") + 
  labs(title = "Residuals by mouse", x = "Mouse", y = "Residuals") +
  stat_summary(aes(y=resid), fun = mean, colour="red", geom="point", size=3)

# "Residuals by mouse and time
ggplot(data=TGCdSet, aes(x= IDmouse, y=resid), group=IDmouse) +
  geom_point() + 
  geom_hline(yintercept=0, linetype="dashed", color = "blue") + 
  labs(title = "Residuals by mouse and time", x = "Mouse", y = "Residuals") +
  stat_summary(aes(y=resid), fun = mean, colour="red", geom="point", size=3) + facet_grid(. ~ ExpGroup)


# Checking a quadratic term for the time variable, overall and by experimental group
fitModel3 <- lme(TVlog ~ time + time2 + (time+time2):ExpGroup, 
                 random= ~1+time|IDmouse,  
                 method="REML", data = TGCdSet)
fitModel4 <- lme(TVlog ~ time + time2 + (time+time2):ExpGroup, 
                 random= ~1+time|IDmouse, weights = varIdent(form = ~1|ExpGroup),
                 method="REML", data = TGCdSet)

# compare models
anova(fitModel4,fitModel3)

# Based on residuals and random effects behaviour we consider the following model as “reference” (gold standard) model:
fitModel <- lme(TVlog ~ time + time2 + (time+time2):ExpGroup, 
                random= ~1+time|IDmouse, weights = varIdent(form = ~1|ExpGroup), 
                method="REML", data = TGCdSet)

# Statistical inference
summary(fitModel)

# Let’s prepare the matrix to specify the contrasts:
mTest = matrix(0, nrow = 2, ncol = 9)
# Synergy on the linear term
mTest[1,4] <- -1
mTest[1,5] <- -1
mTest[1,6] <- 1
# Synergy on the quadratic term
mTest[2,7] <- -1
mTest[2,8] <- -1
mTest[2,9] <- 1
mTest


# Let’s perform the statistical test:
anova(fitModel, L=mTest)


# Step n.1) parameters estimates are extracted from the model
fixedEffects <- as.numeric(fixef(fitModel))

# Step n.2) the point "vehicle group after 14 days" is identified by a design matrix
designMatrix <- matrix(0,nrow = 1, ncol = 9)
designMatrix[1,1] = 1
designMatrix[1,2] = 14
designMatrix[1,3] = 14^2

# Step n.3) point estimates and variance are calculated on log scale
pointEst = designMatrix %*% fixedEffects # point estimate on log scale
mVarCov <- as.matrix(vcov(fitModel)) # variance-covariance matrix on log scale
VarEst = designMatrix %*% mVarCov %*% t(designMatrix) # variance estimate on log scale

# Step n.4) 95% CI are calculated on log scale
low95CI = pointEst - sqrt(VarEst) * qnorm(0.975) # lower 95% CI in log scale
upp95CI = pointEst + sqrt(VarEst) * qnorm(0.975) # upper 95% CI in log scale

# Step n.5) point estimates and 95% CI are calculated on natural scale
pointEst = exp(pointEst)
low95CI = exp(low95CI)
upp95CI = exp(upp95CI)

c(pointEst,low95CI,upp95CI) # print



# Sensitivity analysis

fitSens <- lme(TVlog ~ time + time2 + (time+time2):ExpGroup, 
               random= ~1+time|IDmouse, weights = varIdent(form = ~1|ExpGroup), correlation = corCAR1(form = ~time|IDmouse),
               method="REML", data = TGCdSet)
summary(fitSens)

# The LRT shows that this more complex model could be used instead of the “reference” model.
anova(fitSens,fitModel)

# Let’s perform again the primary statistical test on this alternative model:
anova(fitSens, L=mTest)

##########################################################################