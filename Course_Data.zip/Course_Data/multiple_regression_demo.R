##########################################################################
#====== Section 1: Multiple Regression ===================================
# simple linear regression using trees data (internal data)
# load the data

# Independent variable: Girth, Height
# Dependent variable: Volume
data(trees)

# scatter plots
plot(trees)


# Re-create the original model of Volume against Girth:
m1 = lm(Volume~Girth,data=trees)
summary(m1)

# Now include Height as an additional variable:
m2 = lm(Volume~Girth+Height,data=trees)
summary(m2)

# Try including the interaction term between Girth and Height:
m3 = lm(Volume~Girth*Height, data=trees)
summary(m3)

# try  log-log transformation 
m4 = lm(log(Volume)~log(Girth)+log(Height),data=trees)
summary(m4)

# extract confidence intervals
confint(m4)

# For completeness, we’ll now add the interaction term.
m5 = lm(log(Volume)~log(Girth)*log(Height),data=trees)
summary(m5)

# Given that it would be reasonable to expect the power of Girth to be 2, 
# and Height to be 1, we will now fix those parameters, and instead just 
# estimate the one remaining parameter.
m6 = lm(log(Volume)-log((Girth^2)*Height)~1,data=trees)
summary(m6)

# We can alternatively construct a model with the response being y, and 
# the error term additive rather than multiplicative.
m7 = lm(Volume~0+I(Girth^2):Height,data=trees)
summary(m7)

##########################################################################



##########################################################################
#====== Section 2: Model Selection =======================================

fitted = fitted(m6)
resid = resid(m6)
plot(fitted, resid, xlab="Fitted values", ylab="Raw residuals")

# Of the last two models, the one with the log-Normal error model would 
# seem to have the more Normal residuals.
# This can be inspected by looking at diagnostic plots, 
# by and using the shapiro.test()

fitted = fitted(m6)
resid = resid(m6)
plot(fitted, resid, xlab="Fitted values", ylab="Raw residuals")
shapiro.test(residuals(m6))

fitted = fitted(m7)
resid = resid(m7)
plot(fitted, resid, xlab="Fitted values", ylab="Raw residuals")
shapiro.test(residuals(m7))

# The Akaike Information Criterion (AIC) can help to make decisions regarding which 
# model is the most appropriate. Now calculate the AIC for each of the above models:
summary(m1)
AIC(m1)

summary(m2)
AIC(m2)

summary(m3)
AIC(m3)

summary(m4)
AIC(m4)

summary(m5)
AIC(m5)

summary(m6)
AIC(m6)

summary(m7)
AIC(m7)
##########################################################################




##########################################################################


##########################################################################
#====== Section 3: Practical Exercises ===================================
# Puromycin

# Plot conc (concentration) against rate. What is the nature of the relationship between conc and rate?
# There is a non-linear positive relationship between conc and rate
plot(conc~rate,data=Puromycin)

# Find a transformation that linearises the data and stabilises the variance, making 
# it possible to use linear regression. Create the corresponding linear regression model. Are all terms significant?
# Both terms are significant
plot(log(conc)~rate,data=Puromycin)
m10 = lm(log(conc)~rate,data=Puromycin)
summary(m10)
fitted = fitted(m10)
resid = resid(m10)
plot(fitted, resid, xlab="Fitted values", ylab="Raw residuals")



# Add the state term to the model. What type of variable is this? Is the inclusion 
# of this term appropriate?
# `state` is a boolean factor or indicator variable
# The inclusion of `state` is appropriate, as the term is significant and the diagnostic 
# plots look reasonable 
m11 = lm(log(conc)~rate+state,data=Puromycin)
fitted = fitted(m11)
resid = resid(m11)
plot(fitted, resid, xlab="Fitted values", ylab="Raw residuals")
summary(m11)


# Now add a term representing the interaction between rate and state. Are all terms significant?
# What can you conclude?
# The `state` term is not significant when the interaction between `rate` and `state` is included 
# in the model. So it may be better to remove the `state` term from the model.
m12 = lm(log(conc)~rate*state,data=Puromycin)
summary(m12)

# Given this information, create the regression model you believe to be the most appropriate 
# for modelling conc. Regenerate the plot of conc against rate. Draw curves corresponding to 
# the fitted values of the final model onto this plot (note that two separate curves should be drawn, 
# corresponding to the two levels of state).
m13 = lm(log(conc)~rate+rate:state,data=Puromycin)
summary(m13)

# Solution one:
plot(conc~rate,data=Puromycin)
idx = order(Puromycin$rate)
treated = Puromycin$state[idx] == "treated"
untreated = Puromycin$state[idx] == "untreated"
lines(exp(fitted(m13))[idx][treated]~Puromycin$rate[idx][treated])
lines(exp(fitted(m13))[idx][untreated]~Puromycin$rate[idx][untreated],col="red")

# Solution two (better - more general):
plot(conc~rate,data=Puromycin)
xvals = range(Puromycin$rate)[1]:range(Puromycin$rate)[2]
lines(exp(coef(m13)[1] + coef(m13)[2]*xvals) ~ xvals)
lines(exp(coef(m13)[1] + coef(m13)[2]*xvals + coef(m13)[3]*xvals) ~ xvals, col="red")
##########################################################################
